#ifndef CE2TO3CMD_H
#define CE2TO3CMD_H

#include <string>
#include <list>
using namespace std;

class SXBSchDoc;


class SCe2to3Param{
public:
	string  srcFileName;
	string  destFileName;
	string	largeFontName;
	int		largeFontSize;
	string	smallFontName;
	int		smallFontSize;
	SCe2to3Param();
	void init();
};

int ce2to3(FILE* pCE2, SXBSchDoc* pDoc, const SCe2to3Param& param);

#endif