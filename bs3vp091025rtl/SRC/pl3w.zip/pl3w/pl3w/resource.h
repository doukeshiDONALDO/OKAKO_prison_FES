//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by nlist.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_NLIST_DIALOG                102
#define IDS_DSTOPENERR                  102
#define IDS_SRCOPENERR                  103
#define IDS_FINISHED                    104
#define IDR_MAINFRAME                   128
#define IDI_ICON1                       129
#define IDI_SMALL                       129
#define IDI_ICON2                       131
#define IDI_ICON3                       132
#define IDC_LIST_SRC                    1001
#define IDC_REFSRC                      1002
#define IDC_EDIT_DST                    1003
#define IDC_REFDST                      1004
#define IDC_CLR                         1005
#define IDC_CHECK_MFR                   1006
#define IDC_CHECK_MFRPN                 1007
#define IDC_CHECK_PKG                   1008
#define IDC_CHECK_PKG2                  1009
#define IDC_CHECK_NOTE                  1009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        133
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
