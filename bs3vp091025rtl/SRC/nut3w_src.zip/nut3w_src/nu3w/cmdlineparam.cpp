/****************************************************************************
    NUT3W Numbering software for BSch3V
    Copyright (C) 2004-2005 H.Okada

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*****************************************************************************/

#include "stdafx.h"
#include "cmdlineparam.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

SCmdLineParam::SCmdLineParam(){
	m_flag3sAutoNum = -1;
	m_initNum = 1;
	m_stepNum = 1;
	m_flag = 's';
	m_forceExecute=FALSE;
}

void SCmdLineParam::ParseParam(
				const char* pszParam,
				BOOL bFlag,
				BOOL bLast){
	if(bFlag){
		m_flag = pszParam[0];
		switch(m_flag){
		case 'A':
			m_flag3sAutoNum=1;
			m_flag = 's';
			break;
		case 'a':
			m_flag3sAutoNum=-1;
			m_flag = 's';
			break;
		case 'F':
			m_forceExecute=TRUE;
			m_flag = 's';
			break;
		default:
			break;
		}

	}else if(pszParam[0]){
		switch(m_flag){
		case 's':
			m_strListSrcFiles.AddTail(pszParam);
			break;
		case 'I':
			m_initNum = atoi(pszParam);
			m_flag = 's';
			break;
		case 'S':
			m_stepNum = atoi(pszParam);
			m_flag = 's';
			break;
		default:
			m_flag = 's';
			break;
		}
	}
}
